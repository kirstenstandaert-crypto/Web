from datetime import datetime, timedelta, timezone
import pytest
from app.data.models import Candle
from app.data.validation import DataQualityError, validate_candles
from app.analysis.fvg import detect_fvgs
from app.analysis.structure import find_confirmed_pivots

def candles(rows):
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    return [Candle(timestamp=t+timedelta(hours=i),open=o,high=h,low=l,close=c,volume=100) for i,(o,h,l,c) in enumerate(rows)]

def test_validation_duplicate():
    x=candles([(10,11,9,10)]*3); x[1].timestamp=x[0].timestamp
    with pytest.raises(DataQualityError): validate_candles(x)

def test_validation_bad_ohlc():
    with pytest.raises(DataQualityError): validate_candles(candles([(10,9,8,8.5)]*3))

def test_bullish_fvg():
    x=candles([(10,11,9,10),(10,11,9.5,10.5),(11,13,12,12.5)])
    f=detect_fvgs(x); assert len(f)==1 and f[0].direction=="bullish" and f[0].lower==11 and f[0].upper==12

def test_bearish_fvg():
    x=candles([(12,13,11,12),(12,12.5,10,11),(9,9.5,8,8.5)])
    f=detect_fvgs(x); assert len(f)==1 and f[0].direction=="bearish"

def test_pivot_confirmation_is_after_pivot():
    x=candles([(10,11,9,10),(10,13,9.5,12),(12,12.5,10,11),(11,11.5,9,10),(10,10.5,8,9)])
    for p in find_confirmed_pivots(x,1,1): assert p.confirmed_at>p.timestamp
