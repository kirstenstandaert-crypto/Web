# NASDAQ Trading Terminal — Stage 1

This is the backend/data/analysis foundation for a future NASDAQ LONG setup terminal.

## Included
- FastAPI
- yfinance YahooDataProvider
- provider abstraction
- OHLCV normalization + validation
- file cache + retry/backoff
- HH/HL/LH/LL
- BOS/MSS
- bullish/bearish 3-candle FVG
- deterministic Order Block proxy
- 4H resampling from 1H
- pytest tests

## Install
Recommended Python: 3.12 or 3.13.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Run
```bash
uvicorn app.main:app --reload
```

Endpoints:
- GET /health
- GET /api/v1/market-data/AAPL?interval=1d&period=6mo
- GET /api/v1/analysis/AAPL?interval=1d&period=6mo

## Tests
```bash
pytest -q
```

## Algorithms
Swing pivots use left/right confirmation bars; the pivot gets a later `confirmed_at` timestamp so future candles are not silently treated as known at the pivot candle. BOS is a close beyond the latest confirmed opposite swing. MSS is a BOS opposite the current structural bias. FVG uses the standard three-candle gap (`C.low > A.high` bullish; `C.high < A.low` bearish). Order Block is a conservative, explicit proxy: the last opposite-colored candle before a structure-breaking displacement candle.

This is intentionally Stage 1. Scanner, confluence, trade plans, TP/SL, history, backtest and frontend are later stages.

## Important data limitation
Current yfinance documentation lists intraday intervals including 1m, 5m, 15m, 30m, 60m/1h and notes that intraday data has provider-side history limits. The application does not fabricate missing history.
