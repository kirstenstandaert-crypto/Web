from fastapi import APIRouter, HTTPException, Query
from app.config import get_settings
from app.data.models import Timeframe
from app.data.providers.yahoo import YahooDataProvider
from app.analysis.engine import analyze_ohlcv

router = APIRouter(prefix="/api/v1")
_provider = YahooDataProvider(get_settings())

@router.get("/market-data/{symbol}")
def market_data(symbol: str, interval: Timeframe = Query("1d"), period: str = Query("6mo")):
    try:
        candles = _provider.get_ohlcv(symbol, interval, period)
        return {"symbol": symbol.upper(), "interval": interval, "candles": [c.model_dump(mode="json") for c in candles]}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

@router.get("/analysis/{symbol}")
def analysis(symbol: str, interval: Timeframe = Query("1d"), period: str = Query("6mo")):
    try:
        candles = _provider.get_ohlcv(symbol, interval, period)
        return analyze_ohlcv(candles).model_dump(mode="json")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
