from app.data.models import Candle, Pivot, StructureBreak

def find_confirmed_pivots(candles: list[Candle], left_bars: int = 2, right_bars: int = 2) -> list[Pivot]:
    pivots=[]; last_high=None; last_low=None
    for i in range(left_bars, len(candles)-right_bars):
        c=candles[i]
        highs=[candles[j].high for j in range(i-left_bars,i+right_bars+1) if j!=i]
        lows=[candles[j].low for j in range(i-left_bars,i+right_bars+1) if j!=i]
        if c.high > max(highs):
            label="HH" if last_high is not None and c.high > last_high.price else "LH"
            p=Pivot(timestamp=c.timestamp, confirmed_at=candles[i+right_bars].timestamp, price=c.high, kind="high", label=label); pivots.append(p); last_high=p
        if c.low < min(lows):
            label="HL" if last_low is not None and c.low > last_low.price else "LL"
            p=Pivot(timestamp=c.timestamp, confirmed_at=candles[i+right_bars].timestamp, price=c.low, kind="low", label=label); pivots.append(p); last_low=p
    return sorted(pivots,key=lambda p:p.confirmed_at)

def find_structure_breaks(candles: list[Candle], pivots: list[Pivot]) -> list[StructureBreak]:
    out=[]; active_high=None; active_low=None; bias=None; broken_high=set(); broken_low=set(); pidx=0
    ps=sorted(pivots,key=lambda p:p.confirmed_at)
    for c in candles:
        while pidx<len(ps) and ps[pidx].confirmed_at <= c.timestamp:
            p=ps[pidx]; active_high=p if p.kind=="high" else active_high; active_low=p if p.kind=="low" else active_low; pidx+=1
        if active_high and active_high.timestamp not in broken_high and c.timestamp>active_high.confirmed_at and c.close>active_high.price:
            kind="MSS" if bias=="bearish" else "BOS"; out.append(StructureBreak(timestamp=c.timestamp,direction="bullish",kind=kind,broken_level=active_high.price)); broken_high.add(active_high.timestamp); bias="bullish"
        if active_low and active_low.timestamp not in broken_low and c.timestamp>active_low.confirmed_at and c.close<active_low.price:
            kind="MSS" if bias=="bullish" else "BOS"; out.append(StructureBreak(timestamp=c.timestamp,direction="bearish",kind=kind,broken_level=active_low.price)); broken_low.add(active_low.timestamp); bias="bearish"
    return out
