from app.analysis.structure import find_confirmed_pivots, find_structure_breaks
from app.analysis.fvg import detect_fvgs
from app.analysis.order_blocks import detect_order_blocks
from app.data.models import AnalysisResult, Candle
from app.data.validation import validate_candles

def analyze_ohlcv(candles: list[Candle]) -> AnalysisResult:
    validate_candles(candles, min_candles=10)
    pivots=find_confirmed_pivots(candles); breaks=find_structure_breaks(candles,pivots)
    return AnalysisResult(pivots=pivots,structure_breaks=breaks,fvgs=detect_fvgs(candles),order_blocks=detect_order_blocks(candles,breaks))
