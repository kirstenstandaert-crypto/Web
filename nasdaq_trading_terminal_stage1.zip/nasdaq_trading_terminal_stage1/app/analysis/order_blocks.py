from app.data.models import Candle, OrderBlock

def detect_order_blocks(candles: list[Candle], structure_breaks) -> list[OrderBlock]:
    out=[]
    for br in structure_breaks:
        idx=next((i for i,c in enumerate(candles) if c.timestamp==br.timestamp),None)
        if idx is None: continue
        candidate=None
        for j in range(idx-1,-1,-1):
            c=candles[j]
            if br.direction=="bullish" and c.close<c.open: candidate=c; break
            if br.direction=="bearish" and c.close>c.open: candidate=c; break
        if candidate: out.append(OrderBlock(timestamp=candidate.timestamp,direction=br.direction,lower=candidate.low,upper=candidate.high,displacement_timestamp=br.timestamp))
    return out
