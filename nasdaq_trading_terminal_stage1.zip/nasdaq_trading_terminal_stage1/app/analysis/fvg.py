from app.data.models import Candle, FVG

def detect_fvgs(candles: list[Candle]) -> list[FVG]:
    out=[]
    for i in range(2,len(candles)):
        a,_,c=candles[i-2],candles[i-1],candles[i]
        if c.low>a.high: out.append(FVG(timestamp=c.timestamp,direction="bullish",lower=a.high,upper=c.low))
        elif c.high<a.low: out.append(FVG(timestamp=c.timestamp,direction="bearish",lower=c.high,upper=a.low))
    return out
