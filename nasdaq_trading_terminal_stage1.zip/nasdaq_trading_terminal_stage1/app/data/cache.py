import hashlib, json, time
from pathlib import Path
from typing import Any

class FileCache:
    def __init__(self, directory: str, ttl_seconds: int = 60):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = ttl_seconds
    def _path(self, key: str) -> Path:
        return self.directory / (hashlib.sha256(key.encode()).hexdigest() + ".json")
    def get(self, key: str) -> Any | None:
        path = self._path(key)
        if not path.exists() or time.time() - path.stat().st_mtime > self.ttl_seconds:
            return None
        return json.loads(path.read_text())
    def set(self, key: str, value: Any) -> None:
        self._path(key).write_text(json.dumps(value, default=str))
