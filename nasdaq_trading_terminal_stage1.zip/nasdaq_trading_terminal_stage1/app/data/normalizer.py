from datetime import timezone
import pandas as pd
from app.data.models import Candle

REQUIRED = ["Open", "High", "Low", "Close", "Volume"]

def normalize_ohlcv(df: pd.DataFrame) -> list[Candle]:
    if df is None or df.empty:
        raise ValueError("Provider returned no market data.")
    work = df.copy()
    if isinstance(work.columns, pd.MultiIndex):
        work.columns = work.columns.get_level_values(-1)
    missing = [c for c in REQUIRED if c not in work.columns]
    if missing:
        raise ValueError(f"Missing OHLCV columns: {missing}")
    work = work[REQUIRED].copy()
    work.index = pd.to_datetime(work.index, utc=True)
    work = work.sort_index()
    if work.index.has_duplicates:
        raise ValueError("Duplicate timestamps returned by provider.")
    work = work.dropna(subset=REQUIRED)
    candles = []
    for idx, row in work.iterrows():
        candles.append(Candle(timestamp=idx.to_pydatetime().astimezone(timezone.utc), open=float(row["Open"]), high=float(row["High"]), low=float(row["Low"]), close=float(row["Close"]), volume=float(row["Volume"])))
    return candles
