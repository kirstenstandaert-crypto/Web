from abc import ABC, abstractmethod
from app.data.models import Candle, Timeframe

class MarketDataProvider(ABC):
    @abstractmethod
    def get_ohlcv(self, symbol: str, interval: Timeframe = "1d", period: str = "6mo") -> list[Candle]:
        raise NotImplementedError
