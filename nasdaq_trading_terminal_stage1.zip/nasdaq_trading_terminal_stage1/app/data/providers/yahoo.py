import logging, time
import yfinance as yf
from app.config import Settings
from app.data.cache import FileCache
from app.data.models import Candle, Timeframe
from app.data.normalizer import normalize_ohlcv
from app.data.validation import validate_candles
from app.data.providers.base import MarketDataProvider

logger = logging.getLogger(__name__)
_YF_INTERVAL = {"1m":"1m","5m":"5m","15m":"15m","30m":"30m","1h":"1h","1d":"1d"}

class YahooDataProvider(MarketDataProvider):
    def __init__(self, settings: Settings, retries: int = 3):
        self.settings = settings
        self.cache = FileCache(settings.cache_dir, settings.cache_ttl_seconds)
        self.retries = retries
    def get_ohlcv(self, symbol: str, interval: Timeframe = "1d", period: str = "6mo") -> list[Candle]:
        symbol = symbol.upper().strip()
        if not symbol:
            raise ValueError("Symbol is required.")
        if interval == "4h":
            from app.data.resample import resample_ohlcv
            result = resample_ohlcv(self.get_ohlcv(symbol, "1h", period), "4h")
            validate_candles(result)
            return result
        key = f"yf:{symbol}:{interval}:{period}"
        cached = self.cache.get(key)
        if cached:
            candles = [Candle.model_validate(x) for x in cached]
            validate_candles(candles)
            return candles
        last_error = None
        for attempt in range(self.retries):
            try:
                df = yf.download(tickers=symbol, period=period, interval=_YF_INTERVAL[interval], auto_adjust=True, progress=False, threads=False, timeout=self.settings.yf_timeout_seconds, multi_level_index=False)
                candles = normalize_ohlcv(df)
                validate_candles(candles)
                self.cache.set(key, [c.model_dump(mode="json") for c in candles])
                return candles
            except Exception as exc:
                last_error = exc
                logger.warning("Yahoo download failed for %s attempt %d/%d: %s", symbol, attempt+1, self.retries, exc)
                if attempt < self.retries - 1:
                    time.sleep(2 ** attempt)
        raise RuntimeError(f"Yahoo data unavailable for {symbol}: {last_error}") from last_error
