import pandas as pd
from app.data.models import Candle

def resample_ohlcv(candles: list[Candle], rule: str = "4h") -> list[Candle]:
    if not candles:
        return []
    df = pd.DataFrame([c.model_dump() for c in candles])
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.set_index("timestamp").sort_index()
    out = df.resample(rule, label="left", closed="left").agg({"open":"first","high":"max","low":"min","close":"last","volume":"sum"}).dropna(subset=["open","high","low","close"])
    return [Candle(timestamp=i.to_pydatetime(), open=float(r.open), high=float(r.high), low=float(r.low), close=float(r.close), volume=float(r.volume)) for i,r in out.iterrows()]
