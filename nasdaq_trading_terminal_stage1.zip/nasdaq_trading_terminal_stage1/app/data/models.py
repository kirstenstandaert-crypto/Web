from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field

Timeframe = Literal["1m", "5m", "15m", "30m", "1h", "4h", "1d"]

class Candle(BaseModel):
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = Field(ge=0)

class Pivot(BaseModel):
    timestamp: datetime
    confirmed_at: datetime
    price: float
    kind: Literal["high", "low"]
    label: Literal["HH", "HL", "LH", "LL"]

class StructureBreak(BaseModel):
    timestamp: datetime
    direction: Literal["bullish", "bearish"]
    kind: Literal["BOS", "MSS"]
    broken_level: float

class FVG(BaseModel):
    timestamp: datetime
    direction: Literal["bullish", "bearish"]
    lower: float
    upper: float

class OrderBlock(BaseModel):
    timestamp: datetime
    direction: Literal["bullish", "bearish"]
    lower: float
    upper: float
    displacement_timestamp: datetime

class AnalysisResult(BaseModel):
    pivots: list[Pivot]
    structure_breaks: list[StructureBreak]
    fvgs: list[FVG]
    order_blocks: list[OrderBlock]
