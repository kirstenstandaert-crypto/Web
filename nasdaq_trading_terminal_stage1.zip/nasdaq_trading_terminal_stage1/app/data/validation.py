from app.data.models import Candle

class DataQualityError(ValueError):
    pass

def validate_candles(candles: list[Candle], min_candles: int = 3) -> None:
    if len(candles) < min_candles:
        raise DataQualityError(f"Insufficient candles: {len(candles)} < {min_candles}")
    timestamps = [c.timestamp for c in candles]
    if timestamps != sorted(timestamps):
        raise DataQualityError("Timestamps must be sorted ascending.")
    if len(set(timestamps)) != len(timestamps):
        raise DataQualityError("Duplicate timestamps detected.")
    for c in candles:
        if min(c.open, c.high, c.low, c.close) <= 0:
            raise DataQualityError(f"Non-positive OHLC at {c.timestamp}.")
        if c.high < max(c.open, c.close) or c.low > min(c.open, c.close) or c.high < c.low:
            raise DataQualityError(f"Invalid OHLC relationship at {c.timestamp}.")
        if c.volume < 0:
            raise DataQualityError(f"Negative volume at {c.timestamp}.")
